package com.cg.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.cg.spring.beans.LoginBeans;
import com.cg.spring.repo.ILoginRepo;

@Service
public class LoginServiceImpl implements ILoginService {
	@Autowired
	private ILoginRepo repo;
	
	private JavaMailSender javaMailSender;

	@Override
	public String check(String username, String password) throws Exception {
		String res = null;
		LoginBeans bean = null;
		try {
			bean = repo.findById(username).get();
			
			if (bean != null) {
				if (bean.getPassword().equals(password)) {
					res = bean.getRole();
				}
				else {
					res="fail";
				}
			}
		} catch (Exception e) {
			return null;
			
		}

		return res;

	}

	@Override
	public boolean reset(String username, String newPassword, String confirmPassword) throws Exception {
		boolean output = false;
		try {
			LoginBeans bean = repo.findById(username).get();
			if (newPassword.equals(confirmPassword)) {
				output = true;
				bean.setPassword(newPassword);
				repo.save(bean);
			}
		} catch (Exception e) {
			output = false;
		}

		return output;
	}

	@Override
	public String sendMail(String username) {
		SimpleMailMessage mail = new SimpleMailMessage();
		LoginBeans bean = repo.findById(username).get();
		if(bean.getRole().equals("admin")) {
			mail.setTo("phaneendra.ghantasala@gmail.com");
			mail.setFrom("akhilapatlolla@gmail.com");
			mail.setSubject("Reset Password");
			mail.setText("localhost:7414/reset1/"+username);
			
			javaMailSender.send(mail);
		}
		else if(bean.getRole().equals("merchant")) {
			
			mail.setTo(username);
			mail.setFrom("akhilapatlolla@gmail.com");
			mail.setSubject("Reset Password");
			mail.setText("localhost:7414/reset1/"+username);
			System.out.println("1");
			javaMailSender.send(mail);
			System.out.println("2");
		}
		return "success";
	}

}
