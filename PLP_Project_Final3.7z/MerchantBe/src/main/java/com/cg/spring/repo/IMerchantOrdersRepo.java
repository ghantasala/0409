package com.cg.spring.repo;

import java.util.List;

import com.cg.spring.beans.MerchantOrders;

public interface IMerchantOrdersRepo {

	List<MerchantOrders> displayorders(String email);

}
