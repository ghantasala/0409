package com.cg.spring.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.beans.Admin;
import com.cg.spring.beans.Customer;

import com.cg.spring.beans.MerchantInfo;
import com.cg.spring.beans.MerchantInventory;
import com.cg.spring.repo.IAdminRepo;
import com.cg.spring.repo.ICustomerRepo;
import com.cg.spring.repo.IInventoryRepo;
import com.cg.spring.repo.IMerchantRepo;



@Service
public class AdminServiceImpl implements IAdminService {

	@Autowired
	ICustomerRepo custRepo;
	@Autowired
	IMerchantRepo merchantRepo;
	@Autowired
	IInventoryRepo inventoryRepo;

	@Autowired
	IAdminRepo adminRepo;

	@Override
	public List<Customer> showAllCustomers() {

		List<Customer> custList = new ArrayList<>();
		custRepo.findAll().forEach(custList::add);
		return custList;
	}

	@Override
	public List<MerchantInfo> showAllMerchant() {

		List<MerchantInfo> merchantList = new ArrayList<>();
		merchantRepo.findAll().forEach(merchantList::add);
		return merchantList;
	}

	@Override
	public List<MerchantInventory> showAllInventory() {

		List<MerchantInventory> inventoryList = new ArrayList<>();
		inventoryRepo.findAll().forEach(inventoryList::add);
		return inventoryList;

	}

	@Override
	public List<Admin> showAdminProfile() {

		List<Admin> adminList = new ArrayList<>();
		adminRepo.findAll().forEach(adminList::add);
		return adminList;
	}

}
