package com.cg.spring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.beans.MerchantInfo;
import com.cg.spring.beans.MerchantOrders;
import com.cg.spring.beans.ProductBean;
import com.cg.spring.repo.IIMerchantInventoryRepo;
import com.cg.spring.repo.IMMerchantRepo;
import com.cg.spring.repo.IMerchantOrdersRepo;
import com.cg.spring.repo.IProductRepo;

@Service
public class ServiceImpl implements IService{
	@Autowired
	public  IMMerchantRepo repo;
	@Autowired
	public IMerchantOrdersRepo ordersrepo;
	public  Optional<MerchantInfo> displayInfo(String email) {
		return repo.findById(email);
		
		
	}
	@Override
	public List<MerchantOrders> displayorders(String email) {
		
		return ordersrepo.displayorders(email);
	}
	@Autowired
	public IIMerchantInventoryRepo inventory;
	@Override
	public List<ProductBean> displayinventory(String email) {
		// TODO Auto-generated method stub
		return inventory.displayinnventory(email);
	}
	@Autowired
	public IProductRepo productrepo;
	@Override
	public String addproduct(ProductBean product) {
		productrepo.save(product);
		return "product added sucessfully";
		
	}
	@Override
	public String  deleteproduct(int id) {
		String status="Product not found";
		if(productrepo.existsById(id)) {
			productrepo.deleteById(id);
		status="product deleted sucessfully";
		}
		return status;
		
	}
	
}
