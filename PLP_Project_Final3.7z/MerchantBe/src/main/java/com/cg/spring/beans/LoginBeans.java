package com.cg.spring.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
public class LoginBeans {

	@Id
	private String username;
	private String password;
	@Transient
	private String newPassword;
	@Transient
	private String confirmPassword;
	private String role = "customer";

	public String getRole() {
		return role;
	}

	public LoginBeans(String username, String password, String newPassword, String confirmPassword, String role) {
		super();
		this.username = username;
		this.password = password;
		this.newPassword = newPassword;
		this.confirmPassword = confirmPassword;
		this.role = role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getNewpassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public LoginBeans() {
		// TODO Auto-generated constructor stub
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
