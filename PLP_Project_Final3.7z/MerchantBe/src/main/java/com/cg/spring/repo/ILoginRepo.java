package com.cg.spring.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.spring.beans.LoginBeans;

@Repository
public interface ILoginRepo extends CrudRepository<LoginBeans, String> {

}
